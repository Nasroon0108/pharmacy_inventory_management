# Pharmacy Inventory Management System

A full-stack web application for managing pharmacy inventory with features for adding, editing, deleting, and searching products.

## Features

- **Home Page**: Welcome page with overview
- **About Page**: Information about the pharmacy
- **Contact Page**: Contact form and information
- **Login System**: Secure authentication
- **Dashboard**: Overview of inventory statistics
- **Inventory Management**: 
  - Add new products
  - Edit existing products
  - Delete products
  - Search and filter products
  - Category management
  - Low stock alerts

## Tech Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js, Express.js
- **Database**: SQLite

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

3. Open your browser and navigate to:
```
http://localhost:3000
```

## Default Login

- Username: `admin`
- Password: `admin123`

## Project Structure

```
pharmacy/
├── server.js              # Express server
├── database.js            # Database setup and models
├── routes/                 # API routes
│   ├── auth.js
│   └── inventory.js
├── public/                 # Static files
│   ├── css/
│   ├── js/
│   └── images/
└── views/                  # HTML pages
    ├── index.html
    ├── about.html
    ├── contact.html
    ├── login.html
    ├── dashboard.html
    └── inventory.html
```

