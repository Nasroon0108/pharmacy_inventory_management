let products = [];
let categories = [];
let currentProduct = null;

let lowStockThreshold = 10; // Default value, will be loaded from settings
let expiryAlertDays = 30; // Default value, will be loaded from settings

// Load products
async function loadProducts(search = '', category = '') {
  try {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (category) params.append('category', category);

    const response = await fetch(`/api/products?${params.toString()}`);
    products = await response.json();
    displayProducts();
  } catch (error) {
    console.error('Error loading products:', error);
    showAlert('Failed to load products', 'error');
  }
}

// Load categories
async function loadCategories() {
  try {
    const response = await fetch('/api/categories');
    categories = await response.json();
    populateCategorySelect();
  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

// Load settings on page load
async function loadSettings() {
  try {
    const response = await fetch('/api/settings/low_stock_threshold');
    if (response.ok) {
      const setting = await response.json();
      lowStockThreshold = parseInt(setting.value) || 10;
    }
    
    // Load expiry alert days
    const expiryResponse = await fetch('/api/settings/expiry_alert_days');
    if (expiryResponse.ok) {
      const expirySetting = await expiryResponse.json();
      expiryAlertDays = parseInt(expirySetting.value) || 30;
    }
  } catch (error) {
    console.error('Error loading settings:', error);
    // Use default value if settings fail to load
  }
}

// Check if product is expiring soon
function isExpiringSoon(expiryDate) {
  if (!expiryDate) return false;
  
  const expiry = new Date(expiryDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const daysUntilExpiry = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
  
  return daysUntilExpiry >= 0 && daysUntilExpiry <= expiryAlertDays;
}

// Get days until expiry
function getDaysUntilExpiry(expiryDate) {
  if (!expiryDate) return null;
  
  const expiry = new Date(expiryDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
}

// Display products in table
function displayProducts() {
  const tbody = document.querySelector('#productsTable tbody');
  if (!tbody) return;

  if (products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No products found</td></tr>';
    return;
  }

  // Check if dark mode is active
  const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';
  
  // Dark mode compatible colors
  const lowStockBg = isDarkMode ? '#7f1d1d' : '#fee2e2'; // Dark red for dark mode, light red for light mode
  const expiryUrgentBg = isDarkMode ? '#7f1d1d' : '#fee2e2'; // Dark red for urgent expiry
  const expiryWarningBg = isDarkMode ? '#78350f' : '#fef3c7'; // Dark orange for warning expiry
  const rowBg = isDarkMode ? '#1f1f1f' : '#fef2f2'; // Dark gray for row background

  // Check for low stock items using dynamic threshold
  const lowStockItems = products.filter(p => p.quantity < lowStockThreshold);
  
  // Check for expiring soon items
  const expiringItems = products.filter(p => isExpiringSoon(p.expiry_date));
  
  // Show alerts if there are low stock or expiring items
  if (lowStockItems.length > 0) {
    showLowStockAlert(lowStockItems.length);
  }
  
  if (expiringItems.length > 0) {
    showExpiryAlert(expiringItems.length);
  }

  tbody.innerHTML = products.map(product => {
    const isLowStock = product.quantity < lowStockThreshold;
    const isExpiring = isExpiringSoon(product.expiry_date);
    const daysUntilExpiry = getDaysUntilExpiry(product.expiry_date);
    
    const quantityStyle = isLowStock 
      ? `color: var(--danger-color); font-weight: bold; background-color: ${lowStockBg}; padding: 0.25rem 0.5rem; border-radius: 4px;` 
      : '';
    
    // Expiry date styling
    let expiryStyle = '';
    let expiryBadge = '';
    if (isExpiring && daysUntilExpiry !== null) {
      const isUrgent = daysUntilExpiry <= 7;
      expiryStyle = isUrgent 
        ? `color: var(--danger-color); font-weight: bold; background-color: ${expiryUrgentBg}; padding: 0.25rem 0.5rem; border-radius: 4px;`
        : `color: var(--warning-color); font-weight: bold; background-color: ${expiryWarningBg}; padding: 0.25rem 0.5rem; border-radius: 4px;`;
      expiryBadge = ` <span style="${expiryStyle}">⚠️ ${daysUntilExpiry} day${daysUntilExpiry !== 1 ? 's' : ''}</span>`;
    }
    
    const rowStyle = isLowStock || isExpiring ? `background-color: ${rowBg};` : '';
    
    return `
      <tr style="${rowStyle}">
        <td>${product.name} ${isLowStock ? '⚠️' : ''} ${isExpiring ? '📅' : ''}</td>
        <td>${product.category}</td>
        <td><span style="${quantityStyle}">${product.quantity}</span></td>
        <td>Rs ${parseFloat(product.price).toFixed(2)}</td>
        <td>${product.expiry_date ? new Date(product.expiry_date).toLocaleDateString() : 'N/A'}${expiryBadge}</td>
        <td>${product.supplier || 'N/A'}</td>
        <td>
          <button onclick="editProduct(${product.id})" class="btn btn-primary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;">Edit</button>
          <button onclick="deleteProduct(${product.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">Delete</button>
        </td>
      </tr>
    `;
  }).join('');
}

// Populate category select
function populateCategorySelect() {
  const select = document.getElementById('category');
  const filterSelect = document.getElementById('categoryFilter');
  
  if (select) {
    select.innerHTML = '<option value="">Select Category</option>' +
      categories.map(cat => `<option value="${cat.name}">${cat.name}</option>`).join('');
  }

  if (filterSelect) {
    filterSelect.innerHTML = '<option value="">All Categories</option>' +
      categories.map(cat => `<option value="${cat.name}">${cat.name}</option>`).join('');
  }
}

// Open add product modal
function openAddModal() {
  currentProduct = null;
  document.getElementById('productForm').reset();
  document.getElementById('modalTitle').textContent = 'Add New Product';
  document.getElementById('productModal').style.display = 'block';
}

// Edit product
async function editProduct(id) {
  try {
    const response = await fetch(`/api/products/${id}`);
    const product = await response.json();
    
    currentProduct = product;
    document.getElementById('name').value = product.name;
    document.getElementById('description').value = product.description || '';
    document.getElementById('category').value = product.category;
    document.getElementById('quantity').value = product.quantity;
    document.getElementById('price').value = product.price;
    document.getElementById('expiry_date').value = product.expiry_date || '';
    document.getElementById('supplier').value = product.supplier || '';
    document.getElementById('barcode').value = product.barcode || '';
    
    document.getElementById('modalTitle').textContent = 'Edit Product';
    document.getElementById('productModal').style.display = 'block';
  } catch (error) {
    console.error('Error loading product:', error);
    showAlert('Failed to load product', 'error');
  }
}

// Save product
async function saveProduct() {
  const form = document.getElementById('productForm');
  const formData = new FormData(form);
  
  const productData = {
    name: formData.get('name'),
    description: formData.get('description'),
    category: formData.get('category'),
    quantity: parseInt(formData.get('quantity')),
    price: parseFloat(formData.get('price')),
    expiry_date: formData.get('expiry_date') || null,
    supplier: formData.get('supplier') || null,
    barcode: formData.get('barcode') || null
  };

  try {
    const url = currentProduct 
      ? `/api/products/${currentProduct.id}`
      : '/api/products';
    
    const method = currentProduct ? 'PUT' : 'POST';

    const response = await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(productData)
    });

    const data = await response.json();

    if (response.ok) {
      showAlert(data.message || 'Product saved successfully', 'success');
      closeModal();
      loadProducts();
    } else {
      showAlert(data.error || 'Failed to save product', 'error');
    }
  } catch (error) {
    console.error('Error saving product:', error);
    showAlert('An error occurred', 'error');
  }
}

// Delete product
async function deleteProduct(id) {
  if (!confirm('Are you sure you want to delete this product?')) {
    return;
  }

  try {
    const response = await fetch(`/api/products/${id}`, {
      method: 'DELETE'
    });

    const data = await response.json();

    if (response.ok) {
      showAlert(data.message || 'Product deleted successfully', 'success');
      loadProducts();
    } else {
      showAlert(data.error || 'Failed to delete product', 'error');
    }
  } catch (error) {
    console.error('Error deleting product:', error);
    showAlert('An error occurred', 'error');
  }
}

// Close modal
function closeModal() {
  document.getElementById('productModal').style.display = 'none';
  currentProduct = null;
  document.getElementById('productForm').reset();
}

// Search products
function searchProducts() {
  const search = document.getElementById('searchInput').value;
  const category = document.getElementById('categoryFilter').value;
  loadProducts(search, category);
}

// Show alert
function showAlert(message, type = 'info') {
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type}`;
  alertDiv.textContent = message;
  
  const container = document.querySelector('.container');
  if (container) {
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
      alertDiv.remove();
    }, 5000);
  }
}

// Show low stock alert
function showLowStockAlert(count) {
  const alertContainer = document.getElementById('alertContainer');
  if (!alertContainer) return;
  
  // Remove existing low stock alert
  const existingAlert = document.getElementById('lowStockAlert');
  if (existingAlert) existingAlert.remove();
  
  const alertDiv = document.createElement('div');
  alertDiv.id = 'lowStockAlert';
  alertDiv.className = 'alert alert-error';
  alertDiv.innerHTML = `
    <strong>⚠️ Low Stock Alert:</strong> ${count} product(s) have low stock (quantity < ${lowStockThreshold}). 
    <button onclick="filterLowStock()" class="btn btn-primary" style="margin-left: 1rem; padding: 0.5rem 1rem; font-size: 0.875rem;">View Low Stock Items</button>
  `;
  
  alertContainer.appendChild(alertDiv);
}

// Filter to show only low stock items
function filterLowStock() {
  const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';
  const lowStockBg = isDarkMode ? '#7f1d1d' : '#fee2e2';
  const rowBg = isDarkMode ? '#1f1f1f' : '#fef2f2';
  
  const lowStockProducts = products.filter(p => p.quantity < lowStockThreshold);
  
  const tbody = document.querySelector('#productsTable tbody');
  const resetBtn = document.getElementById('resetBtn');
  
  if (!tbody) return;
  
  if (lowStockProducts.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No low stock items found</td></tr>';
    if (resetBtn) resetBtn.style.display = 'none';
    return;
  }
  
  tbody.innerHTML = lowStockProducts.map(product => `
    <tr style="background-color: ${rowBg};">
      <td>${product.name} ⚠️</td>
      <td>${product.category}</td>
      <td><span style="color: var(--danger-color); font-weight: bold; background-color: ${lowStockBg}; padding: 0.25rem 0.5rem; border-radius: 4px;">${product.quantity}</span></td>
      <td>Rs ${parseFloat(product.price).toFixed(2)}</td>
      <td>${product.expiry_date ? new Date(product.expiry_date).toLocaleDateString() : 'N/A'}</td>
      <td>${product.supplier || 'N/A'}</td>
      <td>
        <button onclick="editProduct(${product.id})" class="btn btn-primary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;">Edit</button>
        <button onclick="deleteProduct(${product.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">Delete</button>
      </td>
    </tr>
  `).join('');
  
  if (resetBtn) resetBtn.style.display = 'inline-block';
}

// Show expiry alert
function showExpiryAlert(count) {
  const alertContainer = document.getElementById('alertContainer');
  if (!alertContainer) return;
  
  // Remove existing expiry alert
  const existingAlert = document.getElementById('expiryAlert');
  if (existingAlert) existingAlert.remove();
  
  const alertDiv = document.createElement('div');
  alertDiv.id = 'expiryAlert';
  alertDiv.className = 'alert alert-warning';
  alertDiv.innerHTML = `
    <strong>📅 Expiry Alert:</strong> ${count} product(s) are expiring within ${expiryAlertDays} days. 
    <button onclick="filterExpiring()" class="btn btn-warning" style="margin-left: 1rem; padding: 0.5rem 1rem; font-size: 0.875rem;">View Expiring Items</button>
  `;
  
  alertContainer.appendChild(alertDiv);
}

// Filter to show only expiring items
function filterExpiring() {
  const isDarkMode = document.documentElement.getAttribute('data-theme') === 'dark';
  const expiryUrgentBg = isDarkMode ? '#7f1d1d' : '#fee2e2';
  const expiryWarningBg = isDarkMode ? '#78350f' : '#fef3c7';
  const rowBg = isDarkMode ? '#1f1f1f' : '#fef2f2';
  
  const expiringProducts = products.filter(p => isExpiringSoon(p.expiry_date));
  
  const tbody = document.querySelector('#productsTable tbody');
  const resetBtn = document.getElementById('resetBtn');
  
  if (!tbody) return;
  
  if (expiringProducts.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No expiring items found</td></tr>';
    if (resetBtn) resetBtn.style.display = 'none';
    return;
  }
  
  tbody.innerHTML = expiringProducts.map(product => {
    const daysUntilExpiry = getDaysUntilExpiry(product.expiry_date);
    const isUrgent = daysUntilExpiry <= 7;
    const expiryStyle = isUrgent 
      ? `color: var(--danger-color); font-weight: bold; background-color: ${expiryUrgentBg}; padding: 0.25rem 0.5rem; border-radius: 4px;`
      : `color: var(--warning-color); font-weight: bold; background-color: ${expiryWarningBg}; padding: 0.25rem 0.5rem; border-radius: 4px;`;
    
    return `
      <tr style="background-color: ${rowBg};">
        <td>${product.name} 📅</td>
        <td>${product.category}</td>
        <td>${product.quantity}</td>
        <td>Rs ${parseFloat(product.price).toFixed(2)}</td>
        <td>
          ${new Date(product.expiry_date).toLocaleDateString()} 
          <span style="${expiryStyle}">⚠️ ${daysUntilExpiry} day${daysUntilExpiry !== 1 ? 's' : ''}</span>
        </td>
        <td>${product.supplier || 'N/A'}</td>
        <td>
          <button onclick="editProduct(${product.id})" class="btn btn-primary" style="padding: 0.5rem 1rem; margin-right: 0.5rem;">Edit</button>
          <button onclick="deleteProduct(${product.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">Delete</button>
        </td>
      </tr>
    `;
  }).join('');
  
  if (resetBtn) resetBtn.style.display = 'inline-block';
}

// Reset filter to show all products
function resetFilter() {
  const resetBtn = document.getElementById('resetBtn');
  if (resetBtn) resetBtn.style.display = 'none';
  
  // Reload all products
  const search = document.getElementById('searchInput').value;
  const category = document.getElementById('categoryFilter').value;
  loadProducts(search, category);
}

// Close modal when clicking outside
window.onclick = function(event) {
  const modal = document.getElementById('productModal');
  if (event.target == modal) {
    closeModal();
  }
}

